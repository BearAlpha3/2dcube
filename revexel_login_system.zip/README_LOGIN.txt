REVEXEL LOGIN / PLAYER DATA

Servidor:
wss://revexel-serverofc.onrender.com

Variáveis do Render:
GOOGLE_CLIENT_ID = ID do cliente Web/OAuth usado pelo app Android
DATABASE_URL = URL do PostgreSQL do Render

Fluxo:
1. Android obtém Google ID Token.
2. Android envia:
   {"type":"auth","id_token":"TOKEN"}
3. Servidor valida o token.
4. Servidor procura o Google "sub".
5. Se não existir, cria PlayerID.
6. Retorna auth_ok com nick e dados.
7. Android envia:
   {"type":"set_nick","nick":"MeuNick"}
8. Servidor verifica formato e duplicidade.
9. Android envia:
   {"type":"play"}
10. Servidor responde play_ok.

Mensagens:
auth
auth_ok
set_nick
nick_ok
nick_error
play
play_ok
move
save
save_ok
players
player_move
ping
pong
error

IMPORTANTE:
O servidor usa o "sub" da conta Google como identificador da conta, não o email.
O email pode ser atualizado no registro; o PlayerID permanece.

O campo money/admin_level não deve ser confiado ao cliente.
Quando o sistema de economia/admin for criado, essas alterações devem acontecer
em comandos server-side.
