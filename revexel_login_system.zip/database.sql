-- O servidor cria esta tabela automaticamente.
-- Use este SQL apenas se quiser criar manualmente.

CREATE TABLE IF NOT EXISTS players (
    player_id VARCHAR(32) PRIMARY KEY,
    google_sub VARCHAR(128) NOT NULL UNIQUE,
    email TEXT NOT NULL,
    nick VARCHAR(16),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_login TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    level INTEGER NOT NULL DEFAULT 1,
    xp BIGINT NOT NULL DEFAULT 0,
    money BIGINT NOT NULL DEFAULT 0,
    gems BIGINT NOT NULL DEFAULT 0,
    rank VARCHAR(32) NOT NULL DEFAULT 'Player',
    admin_level INTEGER NOT NULL DEFAULT 0,
    fighting_style VARCHAR(64) NOT NULL DEFAULT 'None',
    inventory_json TEXT NOT NULL DEFAULT '{}',
    pets_json TEXT NOT NULL DEFAULT '{}',
    powers_json TEXT NOT NULL DEFAULT '{}',
    stats_json TEXT NOT NULL DEFAULT '{}',
    x DOUBLE PRECISION NOT NULL DEFAULT 0,
    y DOUBLE PRECISION NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX IF NOT EXISTS players_nick_lower_unique
ON players (LOWER(nick))
WHERE nick IS NOT NULL;
