package com.revexel.server;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.InetSocketAddress;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class Server extends WebSocketServer {

    private final Map<WebSocket, Player> players =
            new ConcurrentHashMap<WebSocket, Player>();

    private static final String GOOGLE_CLIENT_ID =
            System.getenv("GOOGLE_CLIENT_ID");

    private static Database database;

    private static GoogleIdTokenVerifier googleVerifier;

    public Server(int port) {
        super(new InetSocketAddress("0.0.0.0", port));
    }

    @Override
    public void onStart() {
        System.out.println("================================");
        System.out.println("REVEXEL SERVER ONLINE");
        System.out.println("PORT: " + getPort());
        System.out.println("================================");

        try {
            database = new Database();
            database.init();
            System.out.println("[DATABASE] PostgreSQL ONLINE");
        } catch (Exception e) {
            database = null;
            System.out.println("[DATABASE] OFFLINE: " + e.getMessage());
        }

        try {
            if (GOOGLE_CLIENT_ID != null &&
                    !GOOGLE_CLIENT_ID.trim().isEmpty()) {

                googleVerifier =
                        new GoogleIdTokenVerifier.Builder(
                                GoogleNetHttpTransport.newTrustedTransport(),
                                JacksonFactory.getDefaultInstance()
                        )
                        .setAudience(
                                Collections.singletonList(
                                        GOOGLE_CLIENT_ID.trim()
                                )
                        )
                        .build();

                System.out.println("[GOOGLE] VERIFIER ONLINE");

            } else {
                System.out.println(
                        "[GOOGLE] GOOGLE_CLIENT_ID NOT CONFIGURED"
                );
            }

        } catch (Exception e) {
            System.out.println(
                    "[GOOGLE] VERIFIER ERROR: " +
                    e.getMessage()
            );
        }
    }

    @Override
    public void onOpen(
            WebSocket connection,
            ClientHandshake handshake) {

        String id = UUID.randomUUID()
                .toString()
                .replace("-", "")
                .substring(0, 12);

        Player player = new Player(id);

        players.put(connection, player);

        JSONObject welcome = new JSONObject();
        welcome.put("type", "welcome");
        welcome.put("id", player.id);
        welcome.put("x", player.x);
        welcome.put("y", player.y);
        welcome.put("authenticated", false);

        connection.send(welcome.toString());

        sendWorld(connection);

        System.out.println("[CONNECT] " + player.id);
    }

    @Override
    public void onClose(
            WebSocket connection,
            int code,
            String reason,
            boolean remote) {

        Player player = players.remove(connection);

        if (player == null) {
            return;
        }

        if (player.authenticated && database != null) {
            try {
                database.savePosition(
                        player.id,
                        player.x,
                        player.y
                );
            } catch (Exception e) {
                System.out.println(
                        "[SAVE ERROR] " +
                        player.id +
                        " -> " +
                        e.getMessage()
                );
            }
        }

        JSONObject message = new JSONObject();
        message.put("type", "leave");
        message.put("id", player.id);

        broadcast(message.toString());
        broadcastPlayers();

        System.out.println(
                "[DISCONNECT] " +
                player.id +
                (player.email == null
                        ? ""
                        : " -> " + player.email)
        );
    }

    @Override
    public void onMessage(
            WebSocket connection,
            String message) {

        Player player = players.get(connection);

        if (player == null) {
            return;
        }

        try {
            JSONObject data =
                    new JSONObject(message);

            String type =
                    data.optString("type", "");

            if ("auth".equals(type)) {
                handleAuth(
                        connection,
                        player,
                        data
                );

            } else if ("set_nick".equals(type)) {
                handleSetNick(
                        connection,
                        player,
                        data
                );

            } else if ("play".equals(type)) {
                handlePlay(
                        connection,
                        player
                );

            } else if ("move".equals(type)) {
                handleMove(
                        connection,
                        player,
                        data
                );

            } else if ("save".equals(type)) {
                handleSave(
                        connection,
                        player,
                        data
                );

            } else if ("ping".equals(type)) {

                JSONObject pong =
                        new JSONObject();

                pong.put(
                        "type",
                        "pong"
                );

                connection.send(
                        pong.toString()
                );

            } else if ("join".equals(type)) {

                if (!requireReady(connection, player)) {
                    return;
                }

                JSONObject error =
                        new JSONObject();

                error.put(
                        "type",
                        "error"
                );

                error.put(
                        "message",
                        "Use set_nick and play"
                );

                connection.send(
                        error.toString()
                );
            }

        } catch (Exception e) {

            JSONObject error =
                    new JSONObject();

            error.put(
                    "type",
                    "error"
            );

            error.put(
                    "message",
                    "Invalid message"
            );

            connection.send(
                    error.toString()
            );
        }
    }

    private void handleAuth(
            WebSocket connection,
            Player player,
            JSONObject data) {

        if (googleVerifier == null) {
            sendError(
                    connection,
                    "Google login is not configured on server"
            );
            return;
        }

        String token =
                data.optString(
                        "id_token",
                        ""
                );

        if (token.length() < 20) {
            sendError(
                    connection,
                    "Missing Google ID token"
            );
            return;
        }

        try {
            GoogleIdToken idToken =
                    googleVerifier.verify(token);

            if (idToken == null) {
                sendError(
                        connection,
                        "Invalid Google login"
                );
                return;
            }

            Payload payload =
                    idToken.getPayload();

            String googleSub =
                    payload.getSubject();

            String email =
                    payload.getEmail();

            Boolean verified =
                    payload.getEmailVerified();

            if (googleSub == null ||
                    googleSub.trim().isEmpty()) {

                sendError(
                        connection,
                        "Google account ID missing"
                );
                return;
            }

            if (!Boolean.TRUE.equals(verified)) {
                sendError(
                        connection,
                        "Google email is not verified"
                );
                return;
            }

            PlayerData saved;

            if (database == null) {
                saved = new PlayerData(
                        player.id,
                        "",
                        googleSub,
                        email,
                        1,
                        0,
                        0,
                        0,
                        "Player",
                        0,
                        "None",
                        "{}",
                        "{}",
                        "{}",
                        "{}",
                        0,
                        0
                );
            } else {
                saved =
                        database.findOrCreate(
                                googleSub,
                                email
                        );
            }

            player.id = saved.playerId;
            player.googleSub = googleSub;
            player.email = email;
            player.name =
                    saved.nick == null
                            ? ""
                            : saved.nick;

            player.authenticated = true;
            player.playing = false;

            player.x = saved.x;
            player.y = saved.y;

            JSONObject response =
                    new JSONObject();

            response.put(
                    "type",
                    "auth_ok"
            );

            response.put(
                    "player_id",
                    saved.playerId
            );

            response.put(
                    "nick",
                    player.name
            );

            response.put(
                    "has_nick",
                    !player.name.isEmpty()
            );

            response.put(
                    "email",
                    email
            );

            JSONObject game =
                    saved.toJson();

            response.put(
                    "data",
                    game
            );

            connection.send(
                    response.toString()
            );

            System.out.println(
                    "[AUTH] " +
                    saved.playerId +
                    " -> " +
                    email
            );

            broadcastPlayers();

        } catch (Exception e) {

            System.out.println(
                    "[AUTH ERROR] " +
                    e.getMessage()
            );

            sendError(
                    connection,
                    "Google authentication failed"
            );
        }
    }

    private void handleSetNick(
            WebSocket connection,
            Player player,
            JSONObject data) {

        if (!player.authenticated) {
            sendError(
                    connection,
                    "Login first"
            );
            return;
        }

        String nick =
                data.optString(
                        "nick",
                        ""
                ).trim();

        if (!nick.matches("[A-Za-z0-9_]{4,16}")) {
            sendNickError(
                    connection,
                    "Nick must have 4-16 characters and only letters, numbers or _"
            );
            return;
        }

        String lower =
                nick.toLowerCase(Locale.US);

        if (isReservedNick(lower)) {
            sendNickError(
                    connection,
                    "This nick is reserved"
            );
            return;
        }

        try {
            if (database != null &&
                    database.nickExists(
                            lower,
                            player.id
                    )) {

                sendNickError(
                        connection,
                        "This nick is already in use"
                );

                return;
            }

            player.name = nick;

            if (database != null) {
                database.setNick(
                        player.id,
                        nick
                );
            }

            JSONObject response =
                    new JSONObject();

            response.put(
                    "type",
                    "nick_ok"
            );

            response.put(
                    "nick",
                    nick
            );

            connection.send(
                    response.toString()
            );

            broadcastPlayers();

        } catch (Exception e) {

            sendNickError(
                    connection,
                    "Could not save nick"
            );
        }
    }

    private void handlePlay(
            WebSocket connection,
            Player player) {

        if (!player.authenticated) {
            sendError(
                    connection,
                    "Login first"
            );
            return;
        }

        if (player.name == null ||
                player.name.trim().isEmpty()) {

            sendError(
                    connection,
                    "Choose a nick first"
            );

            return;
        }

        player.playing = true;

        JSONObject response =
                new JSONObject();

        response.put(
                "type",
                "play_ok"
        );

        response.put(
                "player_id",
                player.id
        );

        response.put(
                "nick",
                player.name
        );

        response.put(
                "x",
                player.x
        );

        response.put(
                "y",
                player.y
        );

        connection.send(
                response.toString()
        );

        broadcastPlayers();
    }

    private void handleMove(
            WebSocket connection,
            Player player,
            JSONObject data) {

        if (!requireReady(connection, player)) {
            return;
        }

        double x =
                data.optDouble(
                        "x",
                        player.x
                );

        double y =
                data.optDouble(
                        "y",
                        player.y
                );

        if (Double.isNaN(x) ||
                Double.isInfinite(x)) {
            x = player.x;
        }

        if (Double.isNaN(y) ||
                Double.isInfinite(y)) {
            y = player.y;
        }

        x = Math.max(
                -100000,
                Math.min(100000, x)
        );

        y = Math.max(
                -100000,
                Math.min(100000, y)
        );

        player.x = x;
        player.y = y;

        JSONObject move =
                new JSONObject();

        move.put(
                "type",
                "player_move"
        );

        move.put(
                "id",
                player.id
        );

        move.put(
                "x",
                player.x
        );

        move.put(
                "y",
                player.y
        );

        broadcast(
                move.toString()
        );
    }

    private void handleSave(
            WebSocket connection,
            Player player,
            JSONObject data) {

        if (!requireReady(connection, player)) {
            return;
        }

        double x =
                data.optDouble(
                        "x",
                        player.x
                );

        double y =
                data.optDouble(
                        "y",
                        player.y
                );

        player.x = Math.max(
                -100000,
                Math.min(100000, x)
        );

        player.y = Math.max(
                -100000,
                Math.min(100000, y)
        );

        if (database != null) {
            try {
                database.savePosition(
                        player.id,
                        player.x,
                        player.y
                );
            } catch (Exception e) {
                sendError(
                        connection,
                        "Save failed"
                );
                return;
            }
        }

        JSONObject response =
                new JSONObject();

        response.put(
                "type",
                "save_ok"
        );

        response.put(
                "player_id",
                player.id
        );

        connection.send(
                response.toString()
        );
    }

    private boolean requireReady(
            WebSocket connection,
            Player player) {

        if (!player.authenticated) {
            sendError(
                    connection,
                    "Login first"
            );
            return false;
        }

        if (!player.playing) {
            sendError(
                    connection,
                    "Press play first"
            );
            return false;
        }

        return true;
    }

    private void sendError(
            WebSocket connection,
            String message) {

        JSONObject error =
                new JSONObject();

        error.put(
                "type",
                "error"
        );

        error.put(
                "message",
                message
        );

        connection.send(
                error.toString()
        );
    }

    private void sendNickError(
            WebSocket connection,
            String message) {

        JSONObject error =
                new JSONObject();

        error.put(
                "type",
                "nick_error"
        );

        error.put(
                "message",
                message
        );

        connection.send(
                error.toString()
        );
    }

    private boolean isReservedNick(
            String nick) {

        return nick.equals("admin") ||
                nick.equals("administrator") ||
                nick.equals("owner") ||
                nick.equals("revexel") ||
                nick.equals("moderator") ||
                nick.equals("mod") ||
                nick.equals("system") ||
                nick.equals("server");
    }

    private void sendWorld(
            WebSocket connection) {

        JSONObject world =
                new JSONObject();

        world.put(
                "type",
                "world"
        );

        world.put(
                "name",
                "Revexel"
        );

        world.put(
                "spawnX",
                0
        );

        world.put(
                "spawnY",
                0
        );

        world.put(
                "seed",
                123456789
        );

        connection.send(
                world.toString()
        );
    }

    private void broadcastPlayers() {

        JSONArray array =
                new JSONArray();

        for (Player player :
                players.values()) {

            if (!player.authenticated) {
                continue;
            }

            JSONObject object =
                    new JSONObject();

            object.put(
                    "id",
                    player.id
            );

            object.put(
                    "name",
                    player.name
            );

            object.put(
                    "x",
                    player.x
            );

            object.put(
                    "y",
                    player.y
            );

            object.put(
                    "playing",
                    player.playing
            );

            array.put(object);
        }

        JSONObject message =
                new JSONObject();

        message.put(
                "type",
                "players"
        );

        message.put(
                "players",
                array
        );

        broadcast(
                message.toString()
        );
    }

    @Override
    public void onError(
            WebSocket connection,
            Exception exception) {

        System.out.println(
                "[ERROR] " +
                exception.getMessage()
        );
    }

    public static void main(
            String[] args) {

        int port = 10000;

        String envPort =
                System.getenv("PORT");

        if (envPort != null) {
            try {
                port =
                        Integer.parseInt(
                                envPort
                        );
            } catch (Exception ignored) {
            }
        }

        Server server =
                new Server(port);

        server.setReuseAddr(true);
        server.start();
    }

    private static class Player {

        String id;
        String name;
        String googleSub;
        String email;

        double x;
        double y;

        boolean authenticated;
        boolean playing;

        Player(String id) {
            this.id = id;
            this.name = "";
            this.x = 0;
            this.y = 0;
            this.authenticated = false;
            this.playing = false;
        }
    }

    private static class PlayerData {

        String playerId;
        String nick;
        String googleSub;
        String email;

        int level;
        long xp;
        long money;
        long gems;

        String rank;
        int adminLevel;
        String fightingStyle;

        String inventoryJson;
        String petsJson;
        String powersJson;
        String statsJson;

        double x;
        double y;

        PlayerData(
                String playerId,
                String nick,
                String googleSub,
                String email,
                int level,
                long xp,
                long money,
                long gems,
                String rank,
                int adminLevel,
                String fightingStyle,
                String inventoryJson,
                String petsJson,
                String powersJson,
                String statsJson,
                double x,
                double y) {

            this.playerId = playerId;
            this.nick = nick;
            this.googleSub = googleSub;
            this.email = email;
            this.level = level;
            this.xp = xp;
            this.money = money;
            this.gems = gems;
            this.rank = rank;
            this.adminLevel = adminLevel;
            this.fightingStyle = fightingStyle;
            this.inventoryJson = inventoryJson;
            this.petsJson = petsJson;
            this.powersJson = powersJson;
            this.statsJson = statsJson;
            this.x = x;
            this.y = y;
        }

        JSONObject toJson() {

            JSONObject data =
                    new JSONObject();

            data.put(
                    "level",
                    level
            );

            data.put(
                    "xp",
                    xp
            );

            data.put(
                    "money",
                    money
            );

            data.put(
                    "gems",
                    gems
            );

            data.put(
                    "rank",
                    rank
            );

            data.put(
                    "admin_level",
                    adminLevel
            );

            data.put(
                    "fighting_style",
                    fightingStyle
            );

            data.put(
                    "inventory",
                    new JSONObject(inventoryJson)
            );

            data.put(
                    "pets",
                    new JSONObject(petsJson)
            );

            data.put(
                    "powers",
                    new JSONObject(powersJson)
            );

            data.put(
                    "stats",
                    new JSONObject(statsJson)
            );

            data.put(
                    "x",
                    x
            );

            data.put(
                    "y",
                    y
            );

            return data;
        }
    }

    private static class Database {

        private final String url;
        private final String user;
        private final String password;

        Database() {

            String databaseUrl =
                    System.getenv("DATABASE_URL");

            if (databaseUrl == null ||
                    databaseUrl.trim().isEmpty()) {
                throw new IllegalStateException(
                        "DATABASE_URL is missing"
                );
            }

            String jdbc =
                    databaseUrl.trim();

            if (jdbc.startsWith("postgres://")) {
                jdbc =
                        "jdbc:postgresql://" +
                        jdbc.substring(
                                "postgres://".length()
                        );
            } else if (
                    jdbc.startsWith(
                            "postgresql://"
                    )) {
                jdbc =
                        "jdbc:postgresql://" +
                        jdbc.substring(
                                "postgresql://".length()
                        );
            }

            if (!jdbc.startsWith("jdbc:")) {
                throw new IllegalStateException(
                        "Invalid DATABASE_URL"
                );
            }

            this.url = jdbc;
            this.user = null;
            this.password = null;
        }

        private Connection connection()
                throws SQLException {

            if (user == null) {
                return DriverManager.getConnection(
                        url
                );
            }

            return DriverManager.getConnection(
                    url,
                    user,
                    password
            );
        }

        void init()
                throws SQLException {

            try (Connection c = connection();
                 Statement s = c.createStatement()) {

                s.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS players (" +
                        "player_id VARCHAR(32) PRIMARY KEY," +
                        "google_sub VARCHAR(128) NOT NULL UNIQUE," +
                        "email TEXT NOT NULL," +
                        "nick VARCHAR(16)," +
                        "created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()," +
                        "last_login TIMESTAMPTZ NOT NULL DEFAULT NOW()," +
                        "level INTEGER NOT NULL DEFAULT 1," +
                        "xp BIGINT NOT NULL DEFAULT 0," +
                        "money BIGINT NOT NULL DEFAULT 0," +
                        "gems BIGINT NOT NULL DEFAULT 0," +
                        "rank VARCHAR(32) NOT NULL DEFAULT 'Player'," +
                        "admin_level INTEGER NOT NULL DEFAULT 0," +
                        "fighting_style VARCHAR(64) NOT NULL DEFAULT 'None'," +
                        "inventory_json TEXT NOT NULL DEFAULT '{}'," +
                        "pets_json TEXT NOT NULL DEFAULT '{}'," +
                        "powers_json TEXT NOT NULL DEFAULT '{}'," +
                        "stats_json TEXT NOT NULL DEFAULT '{}'," +
                        "x DOUBLE PRECISION NOT NULL DEFAULT 0," +
                        "y DOUBLE PRECISION NOT NULL DEFAULT 0" +
                        ")"
                );

                s.executeUpdate(
                        "CREATE UNIQUE INDEX IF NOT EXISTS " +
                        "players_nick_lower_unique " +
                        "ON players (LOWER(nick)) " +
                        "WHERE nick IS NOT NULL"
                );
            }
        }

        synchronized PlayerData findOrCreate(
                String googleSub,
                String email)
                throws SQLException {

            try (Connection c = connection()) {

                try (PreparedStatement p =
                             c.prepareStatement(
                                     "SELECT * FROM players " +
                                     "WHERE google_sub = ?"
                             )) {

                    p.setString(
                            1,
                            googleSub
                    );

                    try (ResultSet r =
                                 p.executeQuery()) {

                        if (r.next()) {

                            try (PreparedStatement u =
                                         c.prepareStatement(
                                                 "UPDATE players " +
                                                 "SET email = ?, " +
                                                 "last_login = NOW() " +
                                                 "WHERE google_sub = ?"
                                         )) {

                                u.setString(
                                        1,
                                        email
                                );

                                u.setString(
                                        2,
                                        googleSub
                                );

                                u.executeUpdate();
                            }

                            return readPlayer(r);
                        }
                    }
                }

                String playerId =
                        UUID.randomUUID()
                                .toString()
                                .replace("-", "")
                                .substring(0, 12);

                try (PreparedStatement p =
                             c.prepareStatement(
                                     "INSERT INTO players " +
                                     "(player_id, google_sub, email) " +
                                     "VALUES (?, ?, ?)"
                             )) {

                    p.setString(
                            1,
                            playerId
                    );

                    p.setString(
                            2,
                            googleSub
                    );

                    p.setString(
                            3,
                            email
                    );

                    p.executeUpdate();
                }

                try (PreparedStatement p =
                             c.prepareStatement(
                                     "SELECT * FROM players " +
                                     "WHERE player_id = ?"
                             )) {

                    p.setString(
                            1,
                            playerId
                    );

                    try (ResultSet r =
                                 p.executeQuery()) {

                        if (r.next()) {
                            return readPlayer(r);
                        }
                    }
                }
            }

            throw new SQLException(
                    "Could not create player"
            );
        }

        private PlayerData readPlayer(
                ResultSet r)
                throws SQLException {

            return new PlayerData(
                    r.getString("player_id"),
                    r.getString("nick"),
                    r.getString("google_sub"),
                    r.getString("email"),
                    r.getInt("level"),
                    r.getLong("xp"),
                    r.getLong("money"),
                    r.getLong("gems"),
                    r.getString("rank"),
                    r.getInt("admin_level"),
                    r.getString("fighting_style"),
                    r.getString("inventory_json"),
                    r.getString("pets_json"),
                    r.getString("powers_json"),
                    r.getString("stats_json"),
                    r.getDouble("x"),
                    r.getDouble("y")
            );
        }

        boolean nickExists(
                String lowerNick,
                String playerId)
                throws SQLException {

            try (Connection c = connection();
                 PreparedStatement p =
                         c.prepareStatement(
                                 "SELECT 1 FROM players " +
                                 "WHERE LOWER(nick) = ? " +
                                 "AND player_id <> ? " +
                                 "LIMIT 1"
                         )) {

                p.setString(
                        1,
                        lowerNick
                );

                p.setString(
                        2,
                        playerId
                );

                try (ResultSet r =
                             p.executeQuery()) {

                    return r.next();
                }
            }
        }

        synchronized void setNick(
                String playerId,
                String nick)
                throws SQLException {

            try (Connection c = connection();
                 PreparedStatement p =
                         c.prepareStatement(
                                 "UPDATE players " +
                                 "SET nick = ?, last_login = NOW() " +
                                 "WHERE player_id = ?"
                         )) {

                p.setString(
                        1,
                        nick
                );

                p.setString(
                        2,
                        playerId
                );

                p.executeUpdate();
            }
        }

        synchronized void savePosition(
                String playerId,
                double x,
                double y)
                throws SQLException {

            try (Connection c = connection();
                 PreparedStatement p =
                         c.prepareStatement(
                                 "UPDATE players " +
                                 "SET x = ?, y = ?, " +
                                 "last_login = NOW() " +
                                 "WHERE player_id = ?"
                         )) {

                p.setDouble(
                        1,
                        x
                );

                p.setDouble(
                        2,
                        y
                );

                p.setString(
                        3,
                        playerId
                );

                p.executeUpdate();
            }
        }
    }
}
